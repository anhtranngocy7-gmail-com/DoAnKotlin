package com.laptrinhdidong.nhom3.quanlichitieu.Test

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Nhom3AnTestActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nhom3_an_test)
    }
}