package com.laptrinhdidong.nhom3.quanlichitieu

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Nhom3AnhSignInActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.nhom3_anh_activity_sign_in)
    }
}