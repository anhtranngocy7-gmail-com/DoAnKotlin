package com.laptrinhdidong.nhom3.quanlichitieu.SignUp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.laptrinhdidong.nhom3.quanlichitieu.R

class Nhom3BinhSignUpActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.nhom3_binh_activity_sign_up)
    }
}